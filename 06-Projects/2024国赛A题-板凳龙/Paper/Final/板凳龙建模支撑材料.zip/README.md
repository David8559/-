# 2024 国赛 A 题：板凳龙支撑材料

## 环境

- Python 3.12.5
- NumPy 2.4.3
- Matplotlib 3.10.8
- SymPy 1.14.0

## 验证

```powershell
python -m pip install -r Code/requirements.txt
python -m unittest discover -s Code/tests -p "test_*.py" -v
```

预期结果：35 项测试全部通过。

## 五问运行顺序

```powershell
python Code/solve_problem1.py
python Code/solve_problem2.py
python Code/solve_problem3.py --json-output Paper/Outputs/problem3_result.json
python Code/solve_problem4.py
python Code/solve_problem5.py --json-output Paper/Outputs/problem5_result.json
```

入口脚本、数据模板和输出均使用压缩包内相对路径。`Data/Raw` 只保存三个官方空白 Excel 模板；正式结果在 `Paper/Outputs`，验证图在 `Paper/Figures`。
